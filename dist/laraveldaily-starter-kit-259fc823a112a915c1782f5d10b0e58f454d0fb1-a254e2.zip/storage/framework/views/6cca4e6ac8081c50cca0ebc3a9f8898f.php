<?php if($label): ?>
    <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email</label>
<?php endif; ?>
<input type="email" id="email" placeholder="your@email.com"
    class="w-full px-4 py-2 rounded-lg text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
    required><?php /**PATH /Users/modestasv/Projects/laraveldaily/LaravelDaily-StarterKit/resources/views/components/input.blade.php ENDPATH**/ ?>