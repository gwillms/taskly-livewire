<div class="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 border border-gray-200 dark:border-gray-700">
    <div class="flex items-center justify-between">
        <div>
            <p class="text-sm font-medium text-gray-500 dark:text-gray-400"><?php echo e($title); ?></p>
            <p class="text-2xl font-bold text-gray-800 dark:text-gray-100 mt-1"><?php echo e($value); ?></p>
            <p class="text-xs text-gray-500 flex items-center mt-1">
                <?php if(isset($icon)): ?>
                    <?php echo e($icon); ?>

                <?php endif; ?>
                <?php echo e($slot); ?>

            </p>
        </div>
        <div class="p-3 rounded-full" style="background-color: <?php echo e($color ?? 'var(--tw-bg-opacity, #e0e7ff)'); ?>">
            <?php if(isset($iconRight)): ?>
                <?php echo e($iconRight); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /Users/modestasv/Projects/laraveldaily/starter-kit/resources/views/components/cards/stat.blade.php ENDPATH**/ ?>