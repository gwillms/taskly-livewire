            <aside :class="{ 'w-full md:w-64': sidebarOpen, 'w-0 md:w-16 hidden md:block': !sidebarOpen }"
                class="bg-sidebar text-sidebar-foreground border-r border-gray-200 dark:border-gray-700 sidebar-transition overflow-hidden">
                <!-- Sidebar Content -->
                <div class="h-full flex flex-col">
                    <!-- Sidebar Menu -->
                    <nav class="flex-1 overflow-y-auto custom-scrollbar py-4">
                        <ul class="space-y-1 px-2">
                            <!-- Dashboard -->
                            <?php if (isset($component)) { $__componentOriginal5bd9068df5f01d3037cdaf5fa838e693 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5bd9068df5f01d3037cdaf5fa838e693 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.sidebar-link','data' => ['href' => ''.e(route('dashboard')).'','icon' => 'fas-house','active' => request()->routeIs('dashboard*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.sidebar-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('dashboard')).'','icon' => 'fas-house','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('dashboard*'))]); ?>Dashboard <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5bd9068df5f01d3037cdaf5fa838e693)): ?>
<?php $attributes = $__attributesOriginal5bd9068df5f01d3037cdaf5fa838e693; ?>
<?php unset($__attributesOriginal5bd9068df5f01d3037cdaf5fa838e693); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5bd9068df5f01d3037cdaf5fa838e693)): ?>
<?php $component = $__componentOriginal5bd9068df5f01d3037cdaf5fa838e693; ?>
<?php unset($__componentOriginal5bd9068df5f01d3037cdaf5fa838e693); ?>
<?php endif; ?>
                            
                        </ul>
                    </nav>
                </div>
            </aside>
<?php /**PATH /Users/modestasv/Projects/laraveldaily/starter-kit/resources/views/components/layouts/app/sidebar.blade.php ENDPATH**/ ?>